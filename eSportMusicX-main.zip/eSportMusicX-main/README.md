<p align="center"><a href="https://t.me/REGALTOS_BOTZ"><img src="https://telegra.ph/file/f5652cf748e9f27875bf7.jpg"></a></p>




### 🧪 Get `SESSION_NAME` from below:

[![GenerateString](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@HEXOROP/eSportMusic) ``Pyrogram``


## Heroku Deployment 💜
The easy way to host this bot, deploy to Heroku, Change the app country to Europe (it will help to make the bot stable).

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Bazigar1929/eSportMusicX)


### Special Credits 💖
- [BAZIGAR](https://t.me/BazigarYT): Owner
- [HEYAMAN](https://t.me/Heyaaman) Dev
- [KORA](https://t.me/Kiradeath_god) Dev

### Support & Updates 🎑
<a href="https://t.me/CFC_BOT_SUPPORT"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/REGALTOS_BOTZ"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
